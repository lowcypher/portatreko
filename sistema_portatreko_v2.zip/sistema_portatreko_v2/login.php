<?php
session_start(); /* Starts the session */

$usersFile = '.users';

// Função para copiar um diretório e seu conteúdo
function copyDir($source, $destination) {
    if (is_dir($source)) {
        if (!is_dir($destination)) {
            mkdir($destination, 0777, true);
        }

        $files = scandir($source);
        foreach ($files as $file) {
            if ($file != '.' && $file != '..') {
                copyDir("$source/$file", "$destination/$file");
            }
        }
    } elseif (file_exists($source)) {
        copy($source, $destination);
    }
}

if (isset($_POST['Submit'])) {
    /* Define username and associated password array */
    $logins = array_map('str_getcsv', file($usersFile));

    /* Check and assign submitted Username and Password to new variables */
    $Username = isset($_POST['Username']) ? $_POST['Username'] : '';
    $Password = isset($_POST['Password']) ? $_POST['Password'] : '';

    /* Check Username and Password existence in the defined array */
    $loginValid = false;
    foreach ($logins as $login) {
        if ($login[0] == $Username && $login[1] == $Password) {
            $loginValid = true;
            break;
        }
    }

    if ($loginValid) {
        /* Success: Set session variables and redirect to the user's directory */
        $_SESSION['UserData']['Username'] = $Username;

        // Construct the URL for the user's directory and redirect
        $userDirectory = 'portatreko/' . $Username;
        header("location: $userDirectory");
        exit;
    } else {
        /* Unsuccessful attempt: Set error message */
        //$loginMsg = "<span style='color:red'>Invalid Login Details</span>";
        $loginMsg = "<style='color:red'>Login Inválido";
    }
}

if (isset($_POST['Register'])) {
    $newUsername = isset($_POST['NewUsername']) ? $_POST['NewUsername'] : '';
    $newPassword = isset($_POST['NewPassword']) ? $_POST['NewPassword'] : '';

    // Verifique se o nome de usuário já existe
    $users = array_map('str_getcsv', file($usersFile));
    $existingUsernames = array_column($users, 0);

    if (in_array($newUsername, $existingUsernames)) {
        //$registrationMsg = "<span style='color:red'>Username already exists. Please choose a different username.</span>";
        $registrationMsg = "<style='color:red'>Usuário Já Existe. Por Favor Escolha Outro";
    } else {
        // Adicione o novo usuário aos dados existentes
        $newUser = [$newUsername, $newPassword];
        $users[] = $newUser;

        // Salve os dados atualizados no arquivo .users
        $fileContents = array_map(function ($row) {
            return implode(',', $row);
        }, $users);
        file_put_contents($usersFile, implode("\n", $fileContents));

        // Crie o diretório do usuário
        $userDirectory = 'portatreko/' . $newUsername;
        if (!file_exists($userDirectory)) {
            mkdir($userDirectory, 0777, true);

            // Copie os arquivos/diretórios do sistema de upload para o diretório do usuário
            $sourceDir = 'sistema_upload'; // Diretório de origem dos arquivos do sistema de upload
            copyDir($sourceDir, $userDirectory);
        }

        //$registrationMsg = "<span style='color:green'>Registration successful. You can now log in.</span>";
        $registrationMsg = "<style='color:green'>Registration successful. You can now log in.";
    }
}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>PHP Login Script Without Using Database</title>
    <!-- Adicione o link para o Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/portatreko.css" rel="stylesheet">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center">
                <h1 class="mt-5">Sistema PortaTreko</h1>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="row">
                <div class="col-md-6">
                    <form action="" method="post">
                        <!-- Formulário de Login -->
                        <div class="card mt-4">
                            <div class="card-header">
                                <h3 class="text-center">Login</h3>
                            </div>
                            <div class="card-body">
                                <?php if (isset($loginMsg)) { ?>
                                    <div class="alert alert-danger"><?php echo $loginMsg; ?></div>
                                <?php } ?>
                                <div class="form-group">
                                    <label for="Username">Usuário</label>
                                    <input type="text" class="form-control" name="Username" id="Username" required>
                                </div>
                                <div class="form-group">
                                    <label for="Password">Senha</label>
                                    <input type="password" class="form-control" name="Password" id="Password" required>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block" name="Submit">Login</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-6">
                    <form action="" method="post">
                        <!-- Formulário de Registro de Usuário -->
                        <div class="card mt-4">
                            <div class="card-header">
                                <h3 class="text-center">Registro</h3>
                            </div>
                            <div class="card-body">
                                <?php if (isset($registrationMsg)) { ?>
                                    <div class="alert alert-success"><?php echo $registrationMsg; ?></div>
                                <?php } ?>
                                <div class="form-group">
                                    <label for="NewUsername">Usuário</label>
                                    <input type="text" class="form-control" name="NewUsername" id="NewUsername" required>
                                </div>
                                <div class="form-group">
                                    <label for="NewPassword">Senha</label>
                                    <input type="password" class="form-control" name="NewPassword" id="NewPassword" required>
                                </div>
                                <button type="submit" class="btn btn-success btn-block" name="Register">Registrar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="text-center mt-3">
        <a href="portatreko_publico/" class="btn btn-primary">Acessar Arquivos Públicos</a>
    </div>
</div>
<!-- Adicione o link para o Bootstrap JS (opcional) -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php include 'footer.php'; ?>