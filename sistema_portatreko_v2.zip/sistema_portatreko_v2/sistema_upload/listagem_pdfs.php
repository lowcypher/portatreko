<?php
session_start();

// Verificar se o usuário está logado
        if (isset($_SESSION['UserData']['Username'])) {
            // O usuário está logado, mostrar o formulário de upload
  
        } else {
            // O usuário não está logado, mostrar uma mensagem ou redirecionar para a página de login
            echo '<p>Você precisa fazer login para acessar esta página.</p>';
        }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Listagem de PDFs</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/background1.css">
</head>
<body>

<?php include 'navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="mb-4">Listagem de Arquivos PDF</h2>
        <ul class="list-group">
            <?php
            function listPDFs($dir) {
                $pdfFiles = [];
                if (is_dir($dir)) {
                    $files = scandir($dir);
                    foreach ($files as $file) {
                        if ($file !== '.' && $file !== '..') {
                            $filePath = $dir . '/' . $file;
                            if (is_dir($filePath)) {
                                // Se for um diretório, chame a função recursivamente
                                $subPDFs = listPDFs($filePath);
                                $pdfFiles = array_merge($pdfFiles, $subPDFs);
                            } elseif (pathinfo($file, PATHINFO_EXTENSION) == 'pdf') {
                                // Se for um arquivo PDF, adicione-o à lista
                                $pdfFiles[] = $filePath;
                            }
                        }
                    }
                }
                return $pdfFiles;
            }

            $uploadDir = "uploads/";
            $pdfFiles = listPDFs($uploadDir);

            // Configuração da paginação
            $perPage = 10; // Quantidade de itens por página
            $totalItems = count($pdfFiles);
            $totalPages = ceil($totalItems / $perPage);

            if (isset($_GET['page']) && is_numeric($_GET['page'])) {
                $currentPage = min(max(1, $_GET['page']), $totalPages);
            } else {
                $currentPage = 1;
            }

            $offset = ($currentPage - 1) * $perPage;
            $pdfFiles = array_slice($pdfFiles, $offset, $perPage);

            if (!empty($pdfFiles)) {
                foreach ($pdfFiles as $pdfFile) {
                    echo '<li class="list-group-item"><a href="' . $pdfFile . '" target="_blank">' . basename($pdfFile) . '</a></li>';
                }
            } else {
                echo '<li class="list-group-item">Nenhum arquivo PDF encontrado.</li>';
            }
            ?>
        </ul>

        <!-- Paginação -->
        <nav aria-label="Páginação">
            <ul class="pagination">
                <?php
                if ($totalPages > 1) {
                    // Botão "Primeira"
                    echo '<li class="page-item"><a class="page-link" href="listagem_pdfs.php?page=1">Primeira</a></li>';
                    
                    // Botões numéricos
                    for ($i = 1; $i <= $totalPages; $i++) {
                        echo '<li class="page-item';
                        if ($i == $currentPage) {
                            echo ' active';
                        }
                        echo '"><a class="page-link" href="listagem_pdfs.php?page=' . $i . '">' . $i . '</a></li>';
                    }

                    // Botão "Última"
                    echo '<li class="page-item"><a class="page-link" href="listagem_pdfs.php?page=' . $totalPages . '">Última</a></li>';
                }
                ?>
            </ul>
        </nav>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php include 'footer.php'; ?>