<?php
session_start();

// Verificar se o usuário está logado
        if (isset($_SESSION['UserData']['Username'])) {
            // O usuário está logado, mostrar o formulário de upload
  
        } else {
            // O usuário não está logado, mostrar uma mensagem ou redirecionar para a página de login
            echo '<p>Você precisa fazer login para acessar esta página.</p>';
        }
?>

<style type="text/css">
  span {
  font: 18px Arial, sans-serif;
  display: inline-block;
  transform: rotate(180deg);
}
   
  </style>
<!--
<footer class="bg-dark text-light fixed-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
               <!--<h5>Informações de Contato</h5>
                <p>Endereço: Rua da Exemplo, 1234</p> -->
<!--                 <p>Email: exemplo@email.com</p>
                <p>Telefone: (123) 456-7890</p>
            </div>
            <div class="col-md-6">
                <h5>Links Úteis</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Página Inicial</a></li>
                    <li><a href="#">Sobre Nós</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Contato</a></li> -->
             <!--   </ul>
            </div>
        </div>
        <hr>
        <p class="text-center"> <span>&copy;</span> <?php echo date("Y"); ?> - VDGM666 - Sistema PortaTreko</p>
        <p class="text-center"><a href="https://www.mariomedeiros.eti.br">Mario Medeiros</a></p>
    </div>
</footer> -->
 
<footer class="fixed-bottom">
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)" >
        <!-- © 2023 CopyLeft: -->
        <p class="text-center"> <span>&copy;</span> <?php echo date("Y"); ?> - VDGM666</p>
        <a class="text-white" href="#"
           >Mario Medeiros - Disaster Developer - Sistema PortaTreko</a
          >
      </div>
      <!-- Copyright -->
    </footer>