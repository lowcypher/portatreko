<?php
session_start();

// Verificar se o usuário está logado
        if (isset($_SESSION['UserData']['Username'])) {
            // O usuário está logado, mostrar o formulário de upload
  
        } else {
            // O usuário não está logado, mostrar uma mensagem ou redirecionar para a página de login
            echo '<p>Você precisa fazer login para acessar esta página.</p>';
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Listagem de Documentos (DOC e DOCX)</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/background1.css">
</head>
<body>

<?php include 'navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="mb-4">Listagem de Arquivos DOC e DOCX</h2>
        <ul class="list-group">
            <?php
            function listDocumentos($dir) {
                $documentoFiles = [];
                if (is_dir($dir)) {
                    $files = scandir($dir);
                    foreach ($files as $file) {
                        if ($file !== '.' && $file !== '..') {
                            $filePath = $dir . '/' . $file;
                            if (is_dir($filePath)) {
                                // Se for um diretório, chame a função recursivamente
                                $subDocumentos = listDocumentos($filePath);
                                $documentoFiles = array_merge($documentoFiles, $subDocumentos);
                            } elseif (in_array(pathinfo($file, PATHINFO_EXTENSION), ['doc', 'docx'])) {
                                // Verifica se a extensão é DOC ou DOCX e, se for, adiciona à lista
                                $documentoFiles[] = $filePath;
                            }
                        }
                    }
                }
                return $documentoFiles;
            }

            $uploadDir = "uploads/";
            $documentoFiles = listDocumentos($uploadDir);

            // Configuração da paginação
            $perPage = 10; // Quantidade de itens por página
            $totalItems = count($documentoFiles);
            $totalPages = ceil($totalItems / $perPage);

            if (isset($_GET['page']) && is_numeric($_GET['page'])) {
                $currentPage = min(max(1, $_GET['page']), $totalPages);
            } else {
                $currentPage = 1;
            }

            $offset = ($currentPage - 1) * $perPage;
            $documentoFiles = array_slice($documentoFiles, $offset, $perPage);

            if (!empty($documentoFiles)) {
                foreach ($documentoFiles as $documentoFile) {
                    echo '<li class="list-group-item"><a href="' . $documentoFile . '" target="_blank">' . basename($documentoFile) . '</a></li>';
                }
            } else {
                echo '<li class="list-group-item">Nenhum arquivo de documento encontrado.</li>';
            }
            ?>
        </ul>

        <!-- Paginação -->
        <nav aria-label="Páginação">
            <ul class="pagination">
                <?php
                if ($totalPages > 1) {
                    // Botão "Primeira"
                    echo '<li class="page-item"><a class="page-link" href="listagem_documentos.php?page=1">Primeira</a></li>';
                    
                    // Botões numéricos
                    for ($i = 1; $i <= $totalPages; $i++) {
                        echo '<li class="page-item';
                        if ($i == $currentPage) {
                            echo ' active';
                        }
                        echo '"><a class="page-link" href="listagem_documentos.php?page=' . $i . '">' . $i . '</a></li>';
                    }

                    // Botão "Última"
                    echo '<li class="page-item"><a class="page-link" href="listagem_documentos.php?page=' . $totalPages . '">Última</a></li>';
                }
                ?>
            </ul>
        </nav>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php include 'footer.php'; ?>