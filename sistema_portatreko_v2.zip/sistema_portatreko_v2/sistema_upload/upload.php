<?php
session_start();

// Verificar se o usuário está logado
        if (isset($_SESSION['UserData']['Username'])) {
            // O usuário está logado, mostrar o formulário de upload
  
        } else {
            // O usuário não está logado, mostrar uma mensagem ou redirecionar para a página de login
            echo '<p>Você precisa fazer login para acessar esta página.</p>';
        }
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uploadDir = "uploads/";  // Diretório onde os arquivos serão armazenados
    $uploadedFiles = array();  // Array para armazenar os nomes dos arquivos enviados com sucesso

    // Verifica se o campo de diretório foi preenchido
    $directory = isset($_POST['directory']) ? $_POST['directory'] : '';

    // Verifica se o diretório já existe
    if (!empty($directory)) {
        $uploadDir .= $directory . '/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
    }

    // Resto do código para lidar com o upload de arquivos
}

    

    // Verifica se foram enviados arquivos
    if (isset($_FILES['files'])) {
        $files = $_FILES['files'];

        // Loop pelos arquivos
        for ($i = 0; $i < count($files['name']); $i++) {
            $uploadFile = $uploadDir . basename($files['name'][$i]);

            if (move_uploaded_file($files['tmp_name'][$i], $uploadFile)) {
                $uploadedFiles[] = $files['name'][$i]; // Adiciona o nome do arquivo à lista de arquivos enviados
            }
        }
    }

    // Redirecionar para a página de sucesso com a lista de arquivos enviados
    header("Location: sucesso.php?files=" . implode(',', $uploadedFiles));
    exit;

?>
