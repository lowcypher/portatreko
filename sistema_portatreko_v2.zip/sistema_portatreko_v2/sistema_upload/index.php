<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload de Arquivos</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/background1.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
    <?php
        // Verificar se o usuário está logado
        if (isset($_SESSION['UserData']['Username'])) {
            // O usuário está logado, mostrar o formulário de upload
        ?>
        <h2 class="text-center">Formulário de Envio de Arquivos</h2>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="directory"><b>Nome Do Novo Diretório Onde Ficarão Os Arquivos (opcional):</b></label><p>
                <label for="directory"><b>Obs: Diretórios Já Existentes Estão Listados Abaixo - </b></label>
                <label for="directory"><b>Para Incluir Novos Arquivos Ao Diretório Existente, Informe o Diretório.</b></label>
                <input type="text" class="form-control" id="directory" name="directory">
            </div>
            <div class="form-group">
                <label for="files">Selecione um ou mais arquivos:</label>
                <input type="file" class="form-control-file" id="files" name="files[]" multiple>
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
        <?php
        } else {
            // O usuário não está logado, mostrar uma mensagem ou redirecionar para a página de login
            echo '<p>Você precisa fazer login para acessar esta página.</p>';
        }
        ?>
        <?php

function listDirectories($dir) {
    $directories = array();
    if (is_dir($dir)) {
        $subdirectories = glob($dir . '/*', GLOB_ONLYDIR);
        foreach ($subdirectories as $subdirectory) {
            $directories[] = basename($subdirectory);
        }
    }
    return $directories;
}

$uploadDir = "uploads/";
$directories = listDirectories($uploadDir);

// Agora você pode exibir os diretórios na página
if (!empty($directories)) {
    echo '<h3>Diretórios Existentes:</h3>';
    echo '<ul>';
    foreach ($directories as $directory) {
        echo '<li>' . $directory . '</li>';
    }
    echo '</ul>';
}
?>        





    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php include 'footer.php'; ?>