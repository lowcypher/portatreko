<?php
session_start();

// Verificar se o usuário está logado
        if (isset($_SESSION['UserData']['Username'])) {
            // O usuário está logado, mostrar o formulário de upload
  
        } else {
            // O usuário não está logado, mostrar uma mensagem ou redirecionar para a página de login
            echo '<p>Você precisa fazer login para acessar esta página.</p>';
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Listagem de Planilhas (XLS e XLSX)</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/background1.css">
</head>
<body>

<?php include 'navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="mb-4">Listagem de Arquivos XLS e XLSX</h2>
        <ul class="list-group">
            <?php
            function listPlanilhas($dir) {
                $planilhaFiles = [];
                if (is_dir($dir)) {
                    $files = scandir($dir);
                    foreach ($files as $file) {
                        if ($file !== '.' && $file !== '..') {
                            $filePath = $dir . '/' . $file;
                            if (is_dir($filePath)) {
                                // Se for um diretório, chame a função recursivamente
                                $subPlanilhas = listPlanilhas($filePath);
                                $planilhaFiles = array_merge($planilhaFiles, $subPlanilhas);
                            } elseif (in_array(pathinfo($file, PATHINFO_EXTENSION), ['xls', 'xlsx'])) {
                                // Verifica se a extensão é XLS ou XLSX e, se for, adiciona à lista
                                $planilhaFiles[] = $filePath;
                            }
                        }
                    }
                }
                return $planilhaFiles;
            }

            $uploadDir = "uploads/";
            $planilhaFiles = listPlanilhas($uploadDir);

            // Configuração da paginação
            $perPage = 10; // Quantidade de itens por página
            $totalItems = count($planilhaFiles);
            $totalPages = ceil($totalItems / $perPage);

            if (isset($_GET['page']) && is_numeric($_GET['page'])) {
                $currentPage = min(max(1, $_GET['page']), $totalPages);
            } else {
                $currentPage = 1;
            }

            $offset = ($currentPage - 1) * $perPage;
            $planilhaFiles = array_slice($planilhaFiles, $offset, $perPage);

            if (!empty($planilhaFiles)) {
                foreach ($planilhaFiles as $planilhaFile) {
                    echo '<li class="list-group-item"><a href="' . $planilhaFile . '" target="_blank">' . basename($planilhaFile) . '</a></li>';
                }
            } else {
                echo '<li class="list-group-item">Nenhum arquivo de planilha encontrado.</li>';
            }
            ?>
        </ul>

        <!-- Paginação -->
        <nav aria-label="Páginação">
            <ul class="pagination">
                <?php
                if ($totalPages > 1) {
                    // Botão "Primeira"
                    echo '<li class="page-item"><a class="page-link" href="listagem_planilhas.php?page=1">Primeira</a></li>';
                    
                    // Botões numéricos
                    for ($i = 1; $i <= $totalPages; $i++) {
                        echo '<li class="page-item';
                        if ($i == $currentPage) {
                            echo ' active';
                        }
                        echo '"><a class="page-link" href="listagem_planilhas.php?page=' . $i . '">' . $i . '</a></li>';
                    }

                    // Botão "Última"
                    echo '<li class="page-item"><a class="page-link" href="listagem_planilhas.php?page=' . $totalPages . '">Última</a></li>';
                }
                ?>
            </ul>
        </nav>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php include 'footer.php'; ?>