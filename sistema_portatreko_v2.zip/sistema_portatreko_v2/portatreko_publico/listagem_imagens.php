<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Listagem de Imagens</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/background1.css">
</head>
<body>

<?php include 'navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="mb-4">Listagem de Imagens (JPG, JPEG, PNG, WEBP e GIF)</h2>
        <ul class="list-group">
            <?php
            function listImagens($dir) {
                $imagemFiles = [];
                if (is_dir($dir)) {
                    $files = scandir($dir);
                    foreach ($files as $file) {
                        if ($file !== '.' && $file !== '..') {
                            $filePath = $dir . '/' . $file;
                            if (is_dir($filePath)) {
                                // Se for um diretório, chame a função recursivamente
                                $subImagens = listImagens($filePath);
                                $imagemFiles = array_merge($imagemFiles, $subImagens);
                            } elseif (in_array(pathinfo($file, PATHINFO_EXTENSION), ['jpg', 'jpeg', 'png', 'webp', 'gif'])) {
                                // Verifica se a extensão é JPG, JPEG, PNG, WEBP ou GIF e, se for, adiciona à lista
                                $imagemFiles[] = $filePath;
                            }
                        }
                    }
                }
                return $imagemFiles;
            }

            $uploadDir = "uploads/";
            $imagemFiles = listImagens($uploadDir);

            // Configuração da paginação
            $perPage = 10; // Quantidade de itens por página
            $totalItems = count($imagemFiles);
            $totalPages = ceil($totalItems / $perPage);

            if (isset($_GET['page']) && is_numeric($_GET['page'])) {
                $currentPage = min(max(1, $_GET['page']), $totalPages);
            } else {
                $currentPage = 1;
            }

            $offset = ($currentPage - 1) * $perPage;
            $imagemFiles = array_slice($imagemFiles, $offset, $perPage);

            if (!empty($imagemFiles)) {
                foreach ($imagemFiles as $imagemFile) {
                    echo '<li class="list-group-item"><a href="' . $imagemFile . '" target="_blank">' . basename($imagemFile) . '</a></li>';
                }
            } else {
                echo '<li class="list-group-item">Nenhuma imagem encontrada.</li>';
            }
            ?>
        </ul>

        <!-- Paginação -->
        <nav aria-label="Páginação">
            <ul class="pagination">
                <?php
                if ($totalPages > 1) {
                    // Botão "Primeira"
                    echo '<li class="page-item"><a class="page-link" href="listagem_imagens.php?page=1">Primeira</a></li>';
                    
                    // Botões numéricos
                    for ($i = 1; $i <= $totalPages; $i++) {
                        echo '<li class="page-item';
                        if ($i == $currentPage) {
                            echo ' active';
                        }
                        echo '"><a class="page-link" href="listagem_imagens.php?page=' . $i . '">' . $i . '</a></li>';
                    }

                    // Botão "Última"
                    echo '<li class="page-item"><a class="page-link" href="listagem_imagens.php?page=' . $totalPages . '">Última</a></li>';
                }
                ?>
            </ul>
        </nav>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php include 'footer.php'; ?> 
