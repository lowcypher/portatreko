<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resultados da Pesquisa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/background1.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container mt-5">
        <?php
        function searchFiles($dir, $query) {
            $results = array();

            if (is_dir($dir)) {
                $files = scandir($dir);
                foreach ($files as $file) {
                    if ($file !== '.' && $file !== '..') {
                        $filePath = $dir . '/' . $file;

                        if (is_dir($filePath)) {
                            // Se for um diretório, chame a função recursivamente
                            $subResults = searchFiles($filePath, $query);
                            $results = array_merge($results, $subResults);
                        } elseif (stripos($file, $query) !== false) {
                            // Se for um arquivo e corresponder ao termo de pesquisa, adicione-o aos resultados
                            $results[] = $filePath;
                        }
                    }
                }
            }

            return $results;
        }

        if (isset($_GET['query'])) {
            $query = $_GET['query'];
            $uploadDir = "uploads/";

            $searchResults = searchFiles($uploadDir, $query);

            echo '<h2>Resultados da pesquisa para \'' . $query . '\'</h2>';
            echo '<div class="table-responsive">';
            echo '<table class="table table-striped">';
            echo '<thead>';
            echo '<tr>';
            echo '<th scope="col">Arquivo</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            if (!empty($searchResults)) {
                foreach ($searchResults as $result) {
                    echo '<tr>';
                    echo '<td><a href="' . $result . '" target="_blank">' . $result . '</a></td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr>';
                echo '<td>Nenhum resultado encontrado para \'' . $query . '\'</td>';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
            echo '</div>';
        }
        ?>
    </div>

    <?php include 'footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
